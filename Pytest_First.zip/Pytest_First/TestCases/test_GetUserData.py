import requests
import json
import jsonpath
import pytest

@pytest.mark.smoke
def test_fetch_user_details():
    url="https://reqres.in/api/users?page=2"
    #Send Get Request
    response = requests.get(url)
    #Parse response to JSON format
    json_response = json.loads(response.text)
    print(json_response)


#pytest -m smoke -v TestCases - Will group test cases which are marked as smoke across files present in same folder
#pytest -m "not sanity" -v TestCases - Will group test cases which are NOT marked as sanity across files present in same folder