import requests
import json
import jsonpath
import pytest

#API URL
url = "https://reqres.in/api/users"
a=100
#@pytest.mark.skip("This is not valid for current build")
#@pytest.mark.skipif(a>10,reason="This is not valid for current build")

@pytest.fixture()
def start_exec():
    global file
    file = open('C:\\Users\\user\\Desktop\\Allure\\CreateUser.json','r')

@pytest.mark.smoke
def test_create_new_user(start_exec):
    json_input = file.read()
    request_json = json.loads(json_input)
    response = requests.post(url,request_json)
    assert response.status_code == 201

@pytest.mark.sanity
def test_create_other_user(start_exec):

    json_input = file.read()
    request_json = json.loads(json_input)
    response = requests.post(url,request_json)
    response_json = json.loads(response.text)
    id=jsonpath.jsonpath(response_json,'id')
    print(id[0])

#pytest -k test_create_new_user TestCases - This command will execute only Create New User Test case
#pytest -k test_create TestCases - Execute all test cases which contains the text mentioned